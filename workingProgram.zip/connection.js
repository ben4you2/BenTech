
// Properties
var sd = db.connectionInfo;

// Methods
async  db.query(sql, parameters){
  
}
db.AnimationEvent('smooth').scroll;
console.log(db.connectionInfo);

const result = await db.query(
  `SELECT col FROM tbl WHERE col = 'test'`
);

await db.query('INSERT INTO tbl VALUES ("test")')
        .catch(error => { throw error });

await db.query('SELECT col FROM tbl WHERE col = ?', 'test')
        .catch(e => {
            console.error(e);
            throw e
        });
